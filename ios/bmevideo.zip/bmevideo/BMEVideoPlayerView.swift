import Foundation
import UIKit
import React
import AVFoundation  // Needed for AVPlayerLayer and AVLayerVideoGravity

@objc(BMEVideoPlayerView)
class BMEVideoPlayerView: UIView {
  
  private var player: BMEVideoPlayer?
  private var playerLayer: AVPlayerLayer?
  private var source: NSDictionary?

  override init(frame: CGRect) {
    super.init(frame: frame)
    backgroundColor = .black
    setupTapGestures()
  }

  required init?(coder: NSCoder) {
    super.init(coder: coder)
    setupTapGestures()
  }

  private func setupTapGestures() {
    let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
    addGestureRecognizer(tap)
  }

  @objc private func handleTap(_ g: UITapGestureRecognizer) {
    // Toggle controls or forward to RN via event emitter if needed
  }

  @objc func setSource(_ src: NSDictionary) {
    source = src
    guard let uri = src["uri"] as? String, let url = URL(string: uri) else { return }
    let autoplay = (src["autoplay"] as? Bool) ?? false
    let playURL = CacheProvider.shared.playbackURL(for: url)

    let p = PlayerPool.shared.acquire()
    p.listener = self
    p.load(url: playURL, autoplay: autoplay)
    player = p

    let layer = AVPlayerLayer(player: p.player)
    layer.frame = bounds
    layer.videoGravity = AVLayerVideoGravity.resizeAspect

    // Remove previous layer
    playerLayer?.removeFromSuperlayer()
    self.layer.addSublayer(layer)
    playerLayer = layer
  }

  @objc func play() { player?.play() }
  @objc func pause() { player?.pause() }
  @objc func seekTo(_ seconds: NSNumber) { player?.seek(to: seconds.doubleValue) }
  @objc func setMuted(_ muted: Bool) { player?.setMuted(muted) }
  @objc func setVolume(_ volume: NSNumber) { player?.setVolume(volume.floatValue) }
  @objc func setRate(_ rate: NSNumber) { player?.setRate(rate.floatValue) }

  @objc func releasePlayer() {
    if let p = player { PlayerPool.shared.release(p) }
    player = nil
    playerLayer?.removeFromSuperlayer()
    playerLayer = nil
  }

  override func layoutSubviews() {
    super.layoutSubviews()
    playerLayer?.frame = bounds
  }
}

// MARK: - Player Event Listener
extension BMEVideoPlayerView: PlayerEventListener {

  func onLoad(duration: Double, width: Int, height: Int) {
    sendEvent(BMEVideoPlayerEvent.onLoad, body: [
      "duration": duration,
      "width": width,
      "height": height,
      "target": self.reactTag ?? 0
    ])
  }

  func onProgress(currentTime: Double, duration: Double) {
    sendEvent(BMEVideoPlayerEvent.onProgress, body: [
      "currentTime": currentTime,
      "duration": duration,
      "target": self.reactTag ?? 0
    ])
  }

  func onBuffer(_ buffering: Bool) {
    sendEvent(BMEVideoPlayerEvent.onBuffer, body: [
      "isBuffering": buffering,
      "target": self.reactTag ?? 0
    ])
  }

  func onError(_ message: String) {
    sendEvent(BMEVideoPlayerEvent.onError, body: [
      "error": message,
      "target": self.reactTag ?? 0
    ])
  }

  func onEnd() {
    sendEvent(BMEVideoPlayerEvent.onEnd, body: [
      "target": self.reactTag ?? 0
    ])
  }

  // Helper to send events to React Native
  private func sendEvent(_ eventName: String, body: [String: Any]) {
    if let bridge = self.reactBridge(),
       let emitter = bridge.module(for: BMEEventEmitter.self) as? BMEEventEmitter {
      emitter.send(eventName, body: body)
    }
  }

  private func reactBridge() -> RCTBridge? {
    var nextResponder: UIResponder? = self
    while let r = nextResponder {
      if let b = (r as? RCTBridge) { return b }
      nextResponder = r.next
    }
    // Try global app delegate fallback
    if let delegate = UIApplication.shared.delegate as? RCTBridge { return delegate }
    return nil
  }
}
