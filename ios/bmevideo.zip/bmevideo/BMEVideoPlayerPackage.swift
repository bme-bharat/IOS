import Foundation
// Placeholder to mirror Android's BMEVideoPlayerPackage.kt organization.
// iOS modules are registered via Swift classes and bridging header.
