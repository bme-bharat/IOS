import Foundation
import React

@objc(BMEVideoPlayer) // <- explicit export name must match requireNativeComponent
class BMEVideoPlayerManager: RCTViewManager {

    override static func requiresMainQueueSetup() -> Bool {
        return true
    }

    override func view() -> UIView! {
        return BMEVideoPlayerView()
    }

    @objc override func constantsToExport() -> [AnyHashable : Any]! {
        return ["Events": [
            BMEVideoPlayerEvent.onLoad,
            BMEVideoPlayerEvent.onProgress,
            BMEVideoPlayerEvent.onBuffer,
            BMEVideoPlayerEvent.onError,
            BMEVideoPlayerEvent.onEnd
        ]]
    }

    // MARK: - Commands
    @objc func setSource(_ reactTag: NSNumber, src: NSDictionary) {
        bridge.uiManager.addUIBlock { _, viewRegistry in
            (viewRegistry?[reactTag] as? BMEVideoPlayerView)?.setSource(src)
        }
    }

    @objc func play(_ reactTag: NSNumber) {
        bridge.uiManager.addUIBlock { _, viewRegistry in
            (viewRegistry?[reactTag] as? BMEVideoPlayerView)?.play()
        }
    }

    @objc func pause(_ reactTag: NSNumber) {
        bridge.uiManager.addUIBlock { _, viewRegistry in
            (viewRegistry?[reactTag] as? BMEVideoPlayerView)?.pause()
        }
    }

    @objc func seekTo(_ reactTag: NSNumber, seconds: NSNumber) {
        bridge.uiManager.addUIBlock { _, viewRegistry in
            (viewRegistry?[reactTag] as? BMEVideoPlayerView)?.seekTo(seconds)
        }
    }

    @objc func setMuted(_ reactTag: NSNumber, muted: Bool) {
        bridge.uiManager.addUIBlock { _, viewRegistry in
            (viewRegistry?[reactTag] as? BMEVideoPlayerView)?.setMuted(muted)
        }
    }

    @objc func setVolume(_ reactTag: NSNumber, volume: NSNumber) {
        bridge.uiManager.addUIBlock { _, viewRegistry in
            (viewRegistry?[reactTag] as? BMEVideoPlayerView)?.setVolume(volume)
        }
    }

    @objc func setRate(_ reactTag: NSNumber, rate: NSNumber) {
        bridge.uiManager.addUIBlock { _, viewRegistry in
            (viewRegistry?[reactTag] as? BMEVideoPlayerView)?.setRate(rate)
        }
    }

    @objc func releasePlayer(_ reactTag: NSNumber) {
        bridge.uiManager.addUIBlock { _, viewRegistry in
            (viewRegistry?[reactTag] as? BMEVideoPlayerView)?.releasePlayer()
        }
    }

    @objc func preload(_ url: NSString) {
        PreloadManager.shared.preload(url as String)
    }

    @objc func cancelPreload(_ url: NSString) {
        PreloadManager.shared.cancel(url as String)
    }
}
